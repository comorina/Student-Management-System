#!/usr/bin/env python
# coding: utf-8
#Database Connection.. .
import sqlite3 as sql
con=sql.connect(database='studentdb.sqlite')
cursor=con.cursor()
try:
    cursor.execute('create table course(course text primary key not NULL, course_fee int )')
    cursor.execute('create table students(std_id int primary key,std_name txt, std_email txt, std_mobile txt ,std_course txt, std_course_fee txt, std_deposite)')
    #cursor.execute('select * from students')
    #raw = cursor.fetchall()
    #print(raw)


except Exception as e:
    print(e)
con.commit()
con.close()
# Window.. .

from tkinter import *
from tkinter import messagebox
from tkinter.ttk import Combobox

win = Tk()
win.configure(bg='powder blue')
win.state('zoomed')
win.resizable(width=False, height=False)

# header frame.. .
h_frm = Frame(win)
h_frm.configure(bg='pink')
h_frm.place(x=0,y=0,relwidth=1,relheight=.29)

# header title.. .
titleh_lbl=Label(h_frm, text='Students Management System', bg='pink', font=('', 50,'bold'),fg='blue')
titleh_lbl.place(x=200,y=10)

#footer title.. .
titlef_lbl=Label(h_frm, text='Ducat Institute, Noida A-41, Uttar Pradesh', bg='pink', font=('', 15,''),fg='black')
titlef_lbl.place(x=455,y=100)

def main_body():
    def reset():                #Reset button execution
        u_entry.delete(0,'end')
        p_entry.delete(0,'end')
        u_entry.focus()
    
    def login():                 # login button execution
        u=u_entry.get()
        p=p_entry.get()
        
        if(len(u)==0 or len(p)==0):
            messagebox.showwarning('Validation', "Use Username/Password, can't be empty")
        else:
            if(u=='admin' and p=='admin'):
                frm.destroy()
                login_body()
            else:
                messagebox.showerror('validation',"Invalid Username/Password")    

    # frame for login.. .
    frm = Frame(win)
    frm.configure(bg='powder blue')
    frm.place(x=0,rely=.2,relwidth=1,relheight=.6)
    footer_frame()

    # username.. .
    u_lbl=Label(frm, text='Username:', font=(" ", 20, 'bold'),bg='powder blue', fg='black')
    u_lbl.place(relx=.3, rely=.2)
    #username entry.. .
    u_entry=Entry(frm, font=('',16,''),bd=3)
    u_entry.place(relx=.45, rely=.21)
    u_entry.focus()

    # password.. .
    p_lbl=Label(frm,text='Password:',font=("", 20,'bold'),bg='powder blue',fg='black')
    p_lbl.place(relx=.3, rely=.37)
    
    #password entry.. .
    p_entry=Entry(frm,font=('',16,""),bd=3,show="*")
    p_entry.place(relx=.45, rely=.37)

    # login.. .
    login_btm=Button(frm, text='login',font=('',16,'bold'),bd=3, bg='blue',command=login)
    login_btm.place(relx=.4,rely=.56)

    #reset.. .
    reset_btm=Button(frm, text='reset', font=("",16,'bold'),bg='green',bd=3,command=reset)
    reset_btm.place(relx=.48,rely=.56)
    footer_frame()
    
def footer_frame():
    footer_frm =Frame(win)
    footer_frm.configure(bg='dark blue')
    footer_frm.place(x=0,rely=.97,relwidth=1,relheight=.04)
    
    footer_frm_lbl=Label(footer_frm,text='@powerd by comorina',font=('',10,'bold'),fg='white',bg='dark blue')
    footer_frm_lbl.place(relx=.89,y=0)
    
    footer_frm_lbl2=Label(footer_frm,text='Contact no. 9876543210',font=('',10,'bold'),fg='white',bg='dark blue')
    footer_frm_lbl2.place(x=0,y=0)

def login_body():
    
    def logout_body():                    # logout button execution
        frm.destroy()
        main_body()
        
    def home():                           # home button execution
        frm.destroy()
        login_body()
        footer_frame()
    
    def register_student():              #Register button execution
        frm.destroy()
        register_student_body()
        
            
    def find_student():                 #Find student button execution
        frm.destroy()
        find_student_body()
            
    def deposite():                     # Deposit fee button execution
        frm.destroy()
        deposite_fee_body()
           
    def add_course():                  #Add course buttton execution
        frm.destroy()
        add_course_body()
        
    #Frame.. .
    frm=Frame(win)
    frm.configure(bg='powder blue')
    frm.place(x=0,rely=.2,relwidth=1,relheight=.8) 
    footer_frame()
    
    #Welcom label.. .
    wlc_lbl=Label(frm,text='Welcome, admin',font=('',20,'bold','underline'),bg='powder blue',fg='green')
    wlc_lbl.place(x=3, y=1)
    
    #Register button.. .
    reg_btm=Button(frm,text='Register Student',font=('',16,'bold'),bd=3,width=15,command=register_student)
    reg_btm.place(relx=.4,rely=.2)
    
    #find button.. .
    finstd_btm=Button(frm,text='Find Student',font=('',16,'bold'),bd=3,width=15,command=find_student_body)
    finstd_btm.place(relx=.4,rely=.35)
    
    #Deposit button.. .
    dspf_btm=Button(frm,text='Deposit Fee',font=('',16,'bold'),bd=3,width=15,command=deposite)
    dspf_btm.place(relx=.4,rely=.50)
    
    #course button.. .
    course_btm=Button(frm,text='Add course',font=('',16,'bold'),bd=3,width=15,command=add_course)
    course_btm.place(relx=.4,rely=.65)
    
    #logout button.. .
    logout_btm=Button(frm,text='logout',font=('',16,'bold'),bd=3,command=logout_body)
    logout_btm.place(relx=.92,rely=.0)
    
# Register button body.. .    
def register_student_body():
    def logout_body():
        frm.destroy()
        main_body()
    
    def home():      
        frm.destroy()
        login_body()
    
    def register_std_id():
        pass
    def student_data():                # entring data in database using sqlite
        ids=std_id_entry.get()
        n=std_name_entry.get()
        e=std_email_entry.get()
        m=std_mobile_entry.get()
        cm=course_list.get()
        co,cofe=cm.split()
        df=std_course_fee_entry.get()
        df=int(cofe)-int(df)
        
        con =sql.connect(database='studentdb.sqlite')
        cursor=con.cursor()
        try:
            cursor.execute('insert into students values(?,?,?,?,?,?,?)',(ids,n,e,m,co,cofe,df))
            con.commit()
            messagebox.showinfo('','Registerd')
        except Exception as e:
            messagebox.showinfo('',str(e))
        con.close()
        
        frm.destroy()
        register_student_body()
        
    #Frame.. .
    frm=Frame(win)
    frm.configure(bg='powder blue')
    frm.place(x=0, rely=.2,relwidth=1,relheight=.9)
    footer_frame()
    
    #Welcom label.. .
    wlc_lbl=Label(frm,text='Welcome, admin',font=('',20,'bold','underline'),bg='powder blue',fg='green')
    wlc_lbl.place(x=3, y=1)
    
    #logout button.. .
    logout_btm=Button(frm,text='logout',font=('',16,'bold'),bd=3,command=logout_body)
    logout_btm.place(relx=.92,rely=.0)
    
    #home button.. .
    home_btm=Button(frm,text='Home',font=('',16,'bold'),bd=3,command=home)
    home_btm.place(relx=.85,rely=.0)

    # student id label.. .
    std_id_lbl=Label(frm, text='Student Id:',font=('',18,'bold'),bg='powder blue')
    std_id_lbl.place(relx=.3,rely=.15)
     
    #student id fetch from database.. .
    con=sql.connect(database='studentdb.sqlite')
    cursor=con.cursor()
    cursor.execute('select max(std_id) from students')
    max_id=cursor.fetchone()
    if(max_id[0]==None):
        std_id_db=1
    else:
        std_id_db=max_id[0]+1
    con.close()
    
    # student id Entry.. . 
    std_id_entry=Entry(frm, font=('',15,''),bd=3)
    std_id_entry.place(relx=.49, rely=.157)
    std_id_entry.insert(0,str(std_id_db))
    std_id_entry.configure(state='disabled')
    std_id_entry.focus()
    
    #stdent name label.. .
    std_name_lbl=Label(frm,text='Student name:',font=('',18,'bold'),bg='powder blue')
    std_name_lbl.place(relx=.3,rely=.25)
    
    #student name entry.. .
    std_name_entry=Entry(frm, font=('',15,''),bd=3)
    std_name_entry.place(relx=.49, rely=.257)
    
    #student email.. .
    std_email_lbl=Label(frm,text='Student email:',font=('',18,'bold'),bg='powder blue')
    std_email_lbl.place(relx=.3,rely=.35)
    
    #student email entry.. .
    std_email_entry=Entry(frm, font=('',15,''),bd=3)
    std_email_entry.place(relx=.49, rely=.357)
    
    #student mobile.. .
    std_mobile_lbl=Label(frm,text='Mobile number:',font=('',18,'bold'),bg='powder blue')
    std_mobile_lbl.place(relx=.3,rely=.45)
    
    #student mobile entry
    std_mobile_entry=Entry(frm, font=('',15,''),bd=3)
    std_mobile_entry.place(relx=.49, rely=.457)
    
    #student course.. .
    std_course_lbl=Label(frm,text='Course name:',font=('',18,'bold'),bg='powder blue')
    std_course_lbl.place(relx=.3,rely=.55)
    
    #student course entry.. .
    
    con=sql.connect(database='studentdb.sqlite')
    cursor=con.cursor()
    cursor.execute('select * from course')
    course=cursor.fetchall()
    course.insert(0,'----Select----')
    con.close()
    
    course_list=Combobox(frm,values=course,font=('',14,''))
    course_list.place(relx=.49,rely=.557)
    course_list.current(0)

    std_course_fee_lbl = Label(frm, text='Deposite Fee:', font=('', 18, 'bold'), bg='powder blue')
    std_course_fee_lbl.place(relx=.3, rely=.65)

    std_course_fee_entry = Entry(frm, font=('', 15, ''), bd=3)
    std_course_fee_entry.place(relx=.49, rely=.657)

    #register Button.. .
    register_btm=Button(frm,text='Register',font=('',16,''),bd=3,command=student_data)
    register_btm.place(relx=.45,rely=.75)

    
#find Button body.. .
def find_student_body():
    footer_frame()
    def logout():
        frm.destroy()
        main_body()
    def home():
        frm.destroy()
        login_body()
        
    #Frame.. .
    frm=Frame(win)
    frm.configure(bg='powder blue')
    frm.place(x=0, rely=.2,relwidth=1,relheight=.8)
    footer_frame()
    
    #Welcom label.. .
    wlc_lbl=Label(frm,text='Welcome, admin',font=('',20,'bold','underline'),bg='powder blue',fg='green')
    wlc_lbl.place(x=3, y=1)
    
    #logout button.. .
    logout_btm=Button(frm,text='logout',font=('',16,'bold'),bd=3,command=logout)
    logout_btm.place(relx=.92,rely=.0)
    
    #home button.. .
    home_btm=Button(frm,text='Home',font=('',16,'bold'),bd=3,command=home)
    home_btm.place(relx=.85,rely=.0)
    
    #student id.. .
    std_id_lbl=Label(frm,text='Student Id:',font=('',16,'bold'),bg='powder blue')
    std_id_lbl.place(relx=.35,rely=.15)
    
    #student id entry.. .
    std_id_entry=Entry(frm, font=('',16,''),bd=3)
    std_id_entry.place(relx=.45, rely=.15)
    std_id_entry.focus()
    
    def search_std():
        con=sql.connect(database='studentdb.sqlite')
        cursor=con.cursor()
        search_id=std_id_entry.get()
        
        try:
            cursor.execute('select * from students where std_id=(?)',(search_id))
            std_details=list(cursor.fetchone())
            
            messagebox.showinfo('Student details',f'Student name : {std_details[1]}\nStudent Email: {std_details[2]}\nStudent Mobile no.: {std_details[3]}\nStudent Course:{std_details[4]}\nStudent course fee: {std_details[5]}\nStudent Remaining Fee: {std_details[6]}')
        except Exception as e:
            messagebox.showinfo('','Does not exist.. .')
            
    #student search button.. .
    search_btm=Button(frm,text='Search',font=('',16,''),bd=3,command=search_std)
    search_btm.place(relx=.45,rely=.29)




#Deposite Button body.. .
def deposite_fee_body():
    
    def logout():
        frm.destroy()
        main_body()

    def home():
        frm.destroy()
        login_body()

    def fetch_fee(event):         #fetching data from DB and insert auto data  in remaining box
        id=std_id_entry.get()

        con = sql.connect(database='studentdb.sqlite')
        cursor = con.cursor()
        cursor.execute('select std_deposite from students where std_id=?',(id))
        row=cursor.fetchone()
        print(row)
        if row[0]== None:
            messagebox.showwarning('','Does not exist.. .')
        else:
            std_remaining_fee_entry.configure(state="normal")
            std_remaining_fee_entry.delete(0, "end")
            std_remaining_fee_entry.insert(0, row[0])
            std_remaining_fee_entry.configure(state="disabled")
            std_deposite_amount_entry.focus()

    def deposite():                  # update the deposite data
        dep = std_deposite_amount_entry.get()
        id=std_id_entry.get()

        con=sql.connect(database='studentdb.sqlite')
        cursor=con.cursor()
        cursor.execute('update students set std_deposite=std_deposite-? where std_id=?',(int(dep),id))
        con.commit()
        con.close()
        messagebox.showinfo('', 'fee deposited')

    #Frame.. . 
    frm=Frame(win)
    frm.configure(bg='powder blue')
    frm.place(x=0, rely=.2,relwidth=1,relheight=.8)
    footer_frame()
    
    #Welcom label.. .
    wlc_lbl=Label(frm,text='Welcome, admin',font=('',20,'bold','underline'),bg='powder blue',fg='green')
    wlc_lbl.place(x=3, y=1)
    
    #logout button.. .
    logout_btm=Button(frm,text='logout',font=('',16,'bold'),bd=3,command=logout)
    logout_btm.place(relx=.92,rely=.0)
    
    #home button.. .
    home_btm=Button(frm,text='Home',font=('',16,'bold'),bd=3,command=home)
    home_btm.place(relx=.85,rely=.0)
    
    #student id.. .
    std_id_lbl=Label(frm,text='Student Id:',font=('',16,'bold'),bg='powder blue')
    std_id_lbl.place(relx=.35,rely=.15)

    #student id entry.. .
    std_id_entry=Entry(frm, font=('',16,''),bd=3)
    std_id_entry.place(relx=.485, rely=.15)
    std_id_entry.focus()
    std_id_entry.bind("<FocusOut>", fetch_fee) # event handling 

    #student fee label.. .
    std_remaining_fee_lbl=Label(frm,text='Remaining:',font=('',16,'bold'),bg='powder blue')
    std_remaining_fee_lbl.place(relx=.35,rely=.25)

    #student fee entry.. .
    std_remaining_fee_entry=Entry(frm, font=('',16,''),bd=3,state='disabled')
    std_remaining_fee_entry.place(relx=.485, rely=.257)
    
    #student deposite amount.. .
    std_deposite_amount_lbl=Label(frm,text='Amount:',font=('',16,'bold'),bg='powder blue')
    std_deposite_amount_lbl.place(relx=.35,rely=.45)
    
    #student deposite amount entry.. .
    std_deposite_amount_entry=Entry(frm, font=('',16,''),bd=3)
    std_deposite_amount_entry.place(relx=.485, rely=.457)
    
    #student deposite amount button.. .
    deposite_btm=Button(frm,text='Deposite',font=('',16,'bold'),bd=3,command=deposite)
    deposite_btm.place(relx=.45,rely=.65)

#Add course button body.. .
def add_course_body():
    def logout():
        frm.destroy()
        main_body()
    def home():
        frm.destroy()
        login_body()
        
    def course_db_body():
        n=course_name_entry.get()
        n=n.upper()
        f=course_fee_entry.get()
        print(n,f)
        if(n=='' or f==''):
            messagebox.showinfo('Attention','Course and Fee must be filled.')
        else:
            con = sql.connect(database='studentdb.sqlite')
            cursor=con.cursor()
            try:
                cursor.execute('insert into course values(?,?)',(n,f))
                con.commit()
                messagebox.showinfo('','Course Added')   

            except Exception as e:
                messagebox.showerror('','Course already exist.. .')
            con.close()
        
        
    #Frame.. . 
    frm=Frame(win)
    frm.configure(bg='powder blue')
    frm.place(x=0, rely=.2,relwidth=1,relheight=.8)
    footer_frame()
    
    #Welcom label.. .
    wlc_lbl=Label(frm,text='Welcome, admin',font=('',20,'bold','underline'),bg='powder blue',fg='green')
    wlc_lbl.place(x=3, y=1)
    
    #logout button.. .
    logout_btm=Button(frm,text='logout',font=('',16,'bold'),bd=3,command=logout)
    logout_btm.place(relx=.92,rely=.0)
    
    #home button.. .
    home_btm=Button(frm,text='Home',font=('',16,'bold'),bd=3,command=home)
    home_btm.place(relx=.85,rely=.0)
    
    #course name Label.. .
    course_name_lbl=Label(frm,text='Course:',font=('',16,'bold'),bg='powder blue')
    course_name_lbl.place(relx=.35,rely=.15)
    
    #course name entry.. .
    course_name_entry=Entry(frm,font=('',16,''),bd=3)
    course_name_entry.place(relx=.49,rely=.15)
    course_name_entry.focus()
    
    #course fee Label.. .
    course_fee_lbl=Label(frm,text='Course Fee:',font=('',16,'bold'),bg='powder blue')
    course_fee_lbl.place(relx=.35,rely=.25)
    
    #course fee entry.. .
    course_fee_entry=Entry(frm,font=('',16,''),bd=3)
    course_fee_entry.place(relx=.49,rely=.25)
    
    #add course.. .
    add_course_btm=Button(frm,text='Add Course',font=('',16,'bold'),bd=3,command=course_db_body)
    add_course_btm.place(relx=.45,rely=.45)
       
main_body()
win.mainloop()




